INSERT INTO tb_loja (nome) VALUES
    ('Americanas'),
    ('Fast Shop'),
    ('Magazine Luiza'),
    ('Submarino');