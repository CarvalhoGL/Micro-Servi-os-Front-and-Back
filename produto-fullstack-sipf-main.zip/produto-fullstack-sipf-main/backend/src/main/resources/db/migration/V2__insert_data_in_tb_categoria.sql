INSERT INTO tb_categoria(nome) VALUES
    ('Smartphone'),
    ('Smart TV'),
    ('Notebook'),
    ('Tablet'),
    ('Mouse'),
    ('Teclado');