export type CategoriaInputDTO = {
  nome: string;
};

export type CategoriaDTO = {
  id: number;
  nome: string;
};
