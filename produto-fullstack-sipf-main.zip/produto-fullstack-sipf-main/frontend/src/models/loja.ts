export type LojaDTO = {
    id: number;
    nome: string;
}